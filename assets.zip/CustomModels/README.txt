Drag materials and models into the following directory.
Steamapps/Common/Counter Strike Global Offensive/CSGO
it will not replace anything! Click continue to all errors.